/*
    Author: Tran Trong Hieu
    Copyright: CodeGym Alright reserved.
    Last modified: 03/02/2020
*/
const VIEW_WIDTH = 300;
const VIEW_HEIGHT = 500;
const BACKGROUND_IMAGE_WIDTH = 800;
const NUMBER_OF_MISSILES = 10;
const TIME_OF_FRAME = 30;
const MISSILE_STEP_WIDTH = 20;
const FLIGHT_SCALE = 0.5;
let canvas;
let ctx;

function Background() {
    this.scrollStep = 0;
    this.backgroundImage = new Image();
    this.backgroundImage.src = 'images/background.png';

    let bgrdImg = this.backgroundImage;
    let scrlStep = this.scrollStep;

    this.backgroundImage.onload = function () {
        ctx.drawImage(bgrdImg, scrlStep, 0);
    }

    this.reDraw = function () {
        if (this.scrollStep == BACKGROUND_IMAGE_WIDTH) {
            this.scrollStep = 0;
        } else {
            this.scrollStep++;
            ctx.drawImage(this.backgroundImage, -this.scrollStep, 0);
        }
    }
}

function Flight() {
    this.x = VIEW_WIDTH / 2;
    this.y = VIEW_HEIGHT - 50;
    this.flightImage = new Image();
    this.flightImage.src = "images/ahead.png";

    let flgtImage = this.flightImage;
    let x = this.x;
    let y = this.y;
    this.flightImage.onload = function () {
        ctx.drawImage(flgtImage, x, y);
    }

    this.draw = function () {
        ctx.drawImage(this.flightImage, this.x, this.y);
    }

    this.reDraw = function () {
        ctx.setTransform(FLIGHT_SCALE, 0, 0, FLIGHT_SCALE, this.x, this.y); // sets FLIGHT_SCALE and origin
        ctx.rotate(-(this.x - 200) / 100 / Math.PI / 4);
        ctx.drawImage(this.flightImage, -this.flightImage.width / 2, -this.flightImage.height / 2);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
    }

    this.move = function (e) {
        this.x = e.clientX;
        if (this.x > VIEW_WIDTH)
            this.x = VIEW_WIDTH;
    }

}

function Missile() {

    this.bullets = new Array();
    this.missileImage = new Image();
    this.missileImage.src = "images/missile.png";
    this.numberOfFired = 0;
    for (let i = 0; i < NUMBER_OF_MISSILES; i++) {
        this.bullets.push(Array(VIEW_WIDTH / 2, VIEW_HEIGHT));
    }


    this.reDraw = function () {
        for (let i = 0; i < NUMBER_OF_MISSILES; i++) {
            ctx.drawImage(this.missileImage, this.bullets[i][0], this.bullets[i][1]);
            if (this.bullets[i][1] != VIEW_HEIGHT)
                this.bullets[i][1] -= MISSILE_STEP_WIDTH;
            if (this.bullets[i][1] < 0) {
                this.bullets[i][0] = this.bullets[i][1] = VIEW_HEIGHT;
            }
        }
    }

    this.fire = function (e) {
        for (let i = 0; i < NUMBER_OF_MISSILES; i++) {
            if (this.bullets[i][1] == VIEW_HEIGHT) {
                this.bullets[i][1] = VIEW_HEIGHT - 100;
                this.bullets[i][0] = e.clientX;
                this.numberOfFired++;
                break;
            }
        }
    }

}

function Game() {
    this.background = new Background();
    this.flight = new Flight();
    this.missile = new Missile();

    this.reDraw = function () {
        this.background.reDraw();
        this.flight.reDraw();
        this.missile.reDraw();
        ctx.fillText("Frame: " + this.background.scrollStep, 10, VIEW_HEIGHT - 20);
        ctx.fillText("Number of fired missiles: " + this.missile.numberOfFired, 10, VIEW_HEIGHT - 5);
    }

    this.run = function () {
        let t = this;
        let id = setInterval(function () {
            t.reDraw()
        }, TIME_OF_FRAME);
    }


    this.move = function (e) {
        this.flight.move(e);
    }
}